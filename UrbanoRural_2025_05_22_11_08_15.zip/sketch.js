let scene = 0; // 0 para urbano, 1 para rural

function setup() {
  createCanvas(800, 400);
}

function draw() {
  background(220);
  
  if (scene === 0) {
    drawUrbano();
  } else {
    drawRural();
  }
}

function drawUrbano() {
  // Desenho de uma cidade com carros
  fill(200);
  rect(0, height - 100, width, 100); // rua
  fill(255, 0, 0);
  rect(100, height - 50, 50, 30); // carro
  rect(300, height - 50, 50, 30);
  fill(0);
  textSize(16);
  fill(0);
  text("Urbano", 10, 20);
}

function drawRural() {
  // Desenho de uma estrada com matos e animais
  fill(150, 75, 0);
  rect(0, height - 100, width, 100); // estrada
  fill(34, 139, 34);
  rect(0, height - 200, width, 100); // mato
  // Animais
  fill(255, 255, 0);
  ellipse(200, height - 150, 20, 20); // animal
  ellipse(600, height - 150, 20, 20);
  fill(0);
  textSize(16);
  fill(0);
  text("Rural", 10, 20);
}

function mouseClicked() {
  // Alterna entre urbano e rural ao clicar
  scene = 1 - scene;
}